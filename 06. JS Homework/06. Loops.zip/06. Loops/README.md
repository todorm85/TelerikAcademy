Loops
=====

### Problem 1. Numbers
*	Write a script that prints all the numbers from `1` to `N`.

### Problem 2. Numbers not divisible
*	Write a script that prints all the numbers from `1` to `N`, that are not divisible by `3` and `7` at the same time

### Problem 3. Min/Max of sequence
*	Write a script that finds the `max` and `min` number from a sequence of numbers.

### Problem 4. Lexicographically smallest
*	Write a script that finds the lexicographically smallest and largest property in `document`, `window` and `navigator` objects.
