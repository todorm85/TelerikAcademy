var number = prompt('Enter number') * 1,
	i = 0;

for (var i = 1; i <= number; i++) {
	console.log(i + ' ');
}