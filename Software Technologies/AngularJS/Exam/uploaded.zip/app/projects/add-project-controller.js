(function () {

    function projectsController(notifier, projects, commits, identity, licensesService, location) {
        var vm = this;

        vm.addProject = function (project) {
            projects.addProject(project)
                .then(function (reponse) {
                    notifier.success('Porject added.');
                    location.path('/projects');
                }, function (err) {
                    notifier.error('Unable to add project. Probably no connection.');
                    console.log('Error in promise projectsController.addProject');
                });
        }

        vm.licenses = licensesService.getAll()
            .then(function (response) {
                vm.licenses = response;
            })
    }

    angular
        .module('MyApp.controllers')
        .controller('AddProjectController', ['notifier', 'projects', 'commits', 'identity', 'licenses','$location', projectsController]);
})();
