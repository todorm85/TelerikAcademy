(function () {
    angular
        .module('MyApp.directives')
        .directive('publicProjects', function () {
            return {
                restrict: 'AE',
                templateUrl: 'app/projects/public-projects-directive.html'
                }
        });

})();