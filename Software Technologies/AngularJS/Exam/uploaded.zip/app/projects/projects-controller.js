(function () {

    function projectsController(stats, notifier, projects, commits, identity) {
        var vm = this;
        vm.identity = identity;
        vm.request = {
            Page: 1,
            PageSize: 10,
        };

        vm.prevPage = function () {
            if (vm.request.Page == 1) {
                return;
            }

            vm.request.Page--;
            vm.filter();
        }

        vm.nextPage = function () {
            if (!vm.projects || vm.projects.length == 0) {
                return;
            }

            vm.request.Page++;
            vm.filter();
        }

        vm.filter = function () {
            projects.filterProjects(vm.request)
                .then(function (filteredProjects) {
                    vm.projects = filteredProjects;
                });
        }

        projects.getProjects()
            .then(function (projects) {
                vm.projects = projects;
            }, function (err) {
                console.log('Error in promise get projects at home controller');
                console.log(err);
            });

    }

    angular
        .module('MyApp.controllers')
        .controller('ProjectsController', ['stats', 'notifier', 'projects', 'commits',  'identity', projectsController]);
})();
