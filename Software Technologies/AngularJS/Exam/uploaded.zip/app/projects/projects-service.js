(function () {

    // Data Access Layer object
    function projectsService(data, $q) {

        var PROJECSTS_API = 'api/projects';

        function getProjects() {
            return data.get(PROJECSTS_API);
        }

        function getProjectDetials(id) {
            return data.get(PROJECSTS_API + '/' + id);
        }

        function filterProjects(filters) {
            return data.get(PROJECSTS_API + '/all', filters);
        }

        function addProject(project) {
            return data.post(PROJECSTS_API, project);
        }

        function getCollaborators(id) {
            return data.get(PROJECSTS_API + '/collaborators/' + id);
        }

        function addCollaborator(id, collaborator) {


            return data.put(PROJECSTS_API +'/' + id, collaborator);
        }

        return {
            getProjects,
            filterProjects,
            addProject,
            getProjectDetials,
            getCollaborators,
            addCollaborator
        };
    }

    angular
        .module('MyApp.services')
        .service('projects', ['data', '$q', projectsService]);

})();
