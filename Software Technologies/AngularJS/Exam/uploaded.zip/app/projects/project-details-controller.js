(function () {

    function projectsController(notifier, projects, commits, location, $routeParams, identity, $route) {
        var vm = this;
        var id = $routeParams.id;
        
        vm.id = id;

        vm.isCollaborator;

        vm.request = {
            Page: 1,
            PageSize: 10,
        };

        vm.prevPage = function () {
            if (vm.request.Page == 1) {
                return;
            }

            vm.request.Page--;
            vm.filter();
        }

        vm.nextPage = function () {
            if (!vm.commits || vm.commits.length == 0) {
                return;
            }

            vm.request.Page++;
            vm.filter();
        }

        vm.filter = function () {
            commits.getProjectCommits(id, vm.request)
                .then(function (filteredCommits) {
                    vm.commits = filteredCommits;
                });
        }

        projects.getProjectDetials(id)
            .then(function (response) {
                vm.project = response;
                return commits.getProjectCommits(id);
            }, function (err) {
                console.log('Promise err in projectDetailsController getProjectDetials');
                console.log(err);
            })
            .then(function (commits) {
                vm.commits = commits;
                return projects.getCollaborators(id);
            }, function (err) {
                console.log('Promise err in projectDetailsController getProjectCommits');
                console.log(err);
            })
            .then(function (response) {
                vm.collaborators = response;
                return identity.getUser();
            }, function (err) {
                console.log('Promise err in projectDetailsController getCollaborators');
                console.log(err);
            })
            .then(function (user) {
                console.log(vm.collaborators);
                console.log(user.Email);
                if (vm.collaborators.indexOf(user.Email) >= 0) {
                    vm.isCollaborator = true;
                }
            });

        vm.addCollaborator = function collaboratorAdd (newCollaborator) {
            projects.addCollaborator(id, newCollaborator)
                .then(function (response) {
                    notifier.success('collaborator added');
                    $route.reload();
                }, function (err) {
                    console.log('Promise err in project details controller addCollaborator');
                    console.log(err);
                    notifier.error(err.data.Message);
                });
        }
    }

    angular
        .module('MyApp.controllers')
        .controller('ProjectDetailsController', ['notifier', 'projects', 'commits', '$location', '$routeParams', 'identity','$route', projectsController]);
})();
