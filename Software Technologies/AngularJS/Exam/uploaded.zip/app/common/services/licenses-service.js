(function () {

    // Data Access Layer object
    function licensesService(data, $q) {

        var LICENSES_API = 'api/licenses';

        function getAll() {
            return data.get(LICENSES_API);
        }

        return {
            getAll,
        };
    }

    angular
        .module('MyApp.services')
        .service('licenses', ['data', '$q', licensesService]);

})();
