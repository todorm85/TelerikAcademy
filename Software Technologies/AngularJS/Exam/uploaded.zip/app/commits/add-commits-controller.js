(function () {

    function projectsController(notifier, projects, commits, identity, licensesService, location, $routeParams) {
        var vm = this;
        vm.projectId = $routeParams.id;

        vm.addCommit = function (sourceCode) {
            commit = {
                projectId: vm.projectId,
                SourceCode: sourceCode.SourceCode
            };

            commits.addCommits(commit)
                .then(function (reponse) {
                    notifier.success('Commit added.');
                    location.path('/projects/' + vm.projectId);
                }, function (err) {
                    notifier.error('Unable to add commit. Probably no connection.');
                    console.log('Error in promise projectsController.addCommit');
                    console.log(err);
                });
        }
    }

    angular
        .module('MyApp.controllers')
        .controller('AddCommitsController', ['notifier', 'projects', 'commits', 'identity', 'licenses','$location', '$routeParams', projectsController]);
})();
