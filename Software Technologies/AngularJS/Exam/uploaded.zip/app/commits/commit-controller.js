(function () {

    function commitController(notifier, projects, commits, identity, licensesService, location, $routeParams) {
        var vm = this;
        console.log($routeParams);

        commits.getCommitDetails($routeParams.id)
            .then(function (response) {
                console.log(response);
                vm.commit = response;
            })
    }

    angular
        .module('MyApp.controllers')
        .controller('CommitController', ['notifier', 'projects', 'commits', 'identity', 'licenses', '$location', '$routeParams', commitController]);
})();
