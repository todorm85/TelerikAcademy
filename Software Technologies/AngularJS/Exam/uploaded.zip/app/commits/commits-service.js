(function () {

    // Data Access Layer object
    function projectsService(data, $q) {

        var COMMITS_API = 'api/commits';

        function getCommits() {
            return data.get(COMMITS_API);
        }

        function getCommitDetails(id) {
            return data.get(COMMITS_API + '/' + id);
        }

        // api/commits/byproject/{projectId}
        function getProjectCommits(id, filter) {
            return data.get(COMMITS_API + '/byproject/' + id, filter);
        }

        function addCommits(request) {
            return data.post(COMMITS_API, request);
        }

        return {
            getCommits,
            getProjectCommits,
            addCommits,
            getCommitDetails
        };
    }

    angular
        .module('MyApp.services')
        .service('commits', ['data', '$q', projectsService]);

})();
