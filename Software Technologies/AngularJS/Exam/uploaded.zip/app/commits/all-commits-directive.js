(function () {
    angular
        .module('MyApp.directives')
        .directive('allCommits', function () {
            return {
                restrict: 'AE',
                templateUrl: 'app/commits/all-commits-directive.html'
                }
        });

})();