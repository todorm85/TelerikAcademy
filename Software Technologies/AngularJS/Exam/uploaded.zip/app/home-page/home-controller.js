(function () {

    function homeController(stats, notifier, projects, commits) {
        var vm = this;

        vm.stats = stats.getStats()
            .then(function (stats) {
                vm.stats = stats;
            }, function (err) {
                console.log('Error in promise get stats at home controller');
                console.log(err);
            });

        vm.projects = projects.getProjects()
            .then(function (projects) {
                vm.projects = projects;
            }, function (err) {
                console.log('Error in promise get projects at home controller');
                console.log(err);
            });

        vm.commits = commits.getCommits()
            .then(function (commits) {
                vm.commits = commits;
            }, function (err) {
                console.log('Error in promise get commits at home controller');
                console.log(err);
            });

    }

    angular
        .module('MyApp.controllers')
        .controller('HomePageController', ['stats', 'notifier', 'projects', 'commits', homeController]);
})();
