<h2 class="text-center">Welcome to MyApp exam.</h2>
<p>don`t forget to run this app through a local web server otherwise you will have problems with CORS. This is because I don`t use any IDE like VS or WS, just plain old text editors (sublime). I used http-server on node.js, it`s fastest. To install it simply type in the console (you must have node.js installed!):</p>
<blockquote>npm install http-server -g</blockquote>
<p>then navigate to the dir where the index.html file is, open the console and run</p>
<blockquote>http-server</blockquote>
<p>you can open the web browser and navigate to
<blockquote>http://localhost:<span class="text-muted">{whatever port the http-server says it`s listening}</span></p></blockquote>
<p>Cheers!</p>