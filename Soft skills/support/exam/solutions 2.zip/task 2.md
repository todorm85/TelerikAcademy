Dear Sir/Madam,

I am very sorry to hear that you have certain difficulties using our jQuery library.

In order to provide you with best possible support I would like to ask you to send us with further more specific information about your problem - sample code or screenshots.

Thank you for your business and we expect to hear from you soon.